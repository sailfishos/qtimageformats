/* $Id: dummy.c,v 1.2.2.1 2007/03/21 14:53:46 dron Exp $ */

/*
 * Dummy function, just to be ensure that the library always will be created.
 */

void
libport_dummy_function()
{
        return;
}

